<template>
  <!-- 跟路由 -->
  <router-view style="min-height:100vh"></router-view>
</template>
<script>
export default {
  name: 'Mine',
  components: {
  },
  data() {
    return {
    }
  },
  methods: {

  }
}
</script>
<style rel="stylesheet/scss" lang="scss" >
</style>
